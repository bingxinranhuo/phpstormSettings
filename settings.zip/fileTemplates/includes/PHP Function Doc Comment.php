/**
 *
${PARAM_DOC}
#if (${TYPE_HINT} != "void") * @return ${TYPE_HINT}
#end
${THROWS_DOC}
 * @author jianglai@6.cn
 * @date ${DATE}
*/
